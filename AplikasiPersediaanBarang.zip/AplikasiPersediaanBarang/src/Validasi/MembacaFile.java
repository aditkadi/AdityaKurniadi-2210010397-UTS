package Validasi;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MembacaFile {
    public static void main(String[] args) {
        // Tentukan lokasi file
        String filePath = "D:\\StokBarang.txt"; 

        try {
            // Buat objek Scanner untuk membaca file
            Scanner scanner = new Scanner(new File(filePath));

            // Baca file baris per baris
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }

            // Tutup scanner setelah selesai
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
